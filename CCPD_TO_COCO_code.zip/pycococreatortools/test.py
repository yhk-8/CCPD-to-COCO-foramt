a  =[[411.0, 568.0], [273.0, 569.0], [267.0, 512.0], [405.0, 511.0]]
import numpy as np
mulArrays = a
b= list(np.array(mulArrays).flatten())
c = [b]

print(c)